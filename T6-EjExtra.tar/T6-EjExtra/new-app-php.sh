#!/bin/bash

oc new-app  --as-deployment-config --name quotesapi -o name \
    -e DATABASE_USER=quoteapp \
    -e DATABASE_PASSWORD=redhat \
    -e DATABASE_NAME=quotesdb \
    -e DATABASE_SERVICE_NAME=quotesdb \
    "php:7.4-ubi8~https://github.com/redhattraining/DO288-apps" \
    --context-dir quotes
