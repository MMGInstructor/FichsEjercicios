#!/bin/bash


oc new-app  --as-deployment-config --file=quotes-template.yaml \
    -p APP_GIT_URL=https://github.com/redhattraining/DO288-apps \
    -p PASSWORD=mypass
