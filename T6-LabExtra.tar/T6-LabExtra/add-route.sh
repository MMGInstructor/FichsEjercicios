#!/bin/bash

oc expose svc/todoapp \
    --hostname todo.apps.ocp4.example.com
