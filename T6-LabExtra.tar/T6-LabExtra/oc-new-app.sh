#!/bin/bash


oc new-app  --as-deployment-config --name todo --file ~/todo-template.yaml \
    -p APP_GIT_URL=https://github.com/redhattraining/DO288-apps \
    -p NPM_PROXY=http://nexus-infra.apps.ocp4.example.com/repository/npm \
    -p PASSWORD=mypass \
    -p CLEAN_DATABASE=false \
    # ADD MISSING PARAMETERS AND CHANGE PARAMETER VALUES IF NEEDED
