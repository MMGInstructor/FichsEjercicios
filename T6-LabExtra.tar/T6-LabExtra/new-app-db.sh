#!/bin/bash

oc new-app  --as-deployment-config --name tododb -i mysql:8.0 \
    -e MYSQL_USER=todoapp \
    -e MYSQL_PASSWORD=redhat \
    -e MYSQL_DATABASE=tododb
