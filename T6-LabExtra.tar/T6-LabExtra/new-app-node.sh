#!/bin/bash

oc new-app  --as-deployment-config --name todoapp -i nodejs:18-ubi8 \
    --context-dir todo-single
    --build-env npm_config_registry=\
http://nexus-infra.apps.ocp4.example.com/repository/npm \
    -e DATABASE_NAME=tododb \
    -e DATABASE_USER=todoapp \
    -e DATABASE_PASSWORD=redhat \
    -e DATABASE_SVC=tododb \
    -e DATABASE_INIT=true \
    https://github.com/redhattraining/DO288-apps
